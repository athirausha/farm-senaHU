$(document).ready(function(){

  console.log("========== Satrt ============")

  $.ajax({
    url: '/relation_maters',
    type: 'POST',
    data: {csrfmiddlewaretoken: window.CSRF_TOKEN},
    success: function (data)
    {
        console.log(data);
        for(i=0; i<data.Result.length; i++)
        {
          console.log(data.Result[i]);
          $("#master_table_relation_select").append('<option value="'+data.Result[i].pk+'">'+data.Result[i].base_name+'</option>')

        }
    },
    error:function(e)
    {
        console.log(e)
    }
  });

  /* Relation column of tables fetching */
  $(document).on('change','#master_table_relation_select',function(){
    $.ajax({
      url: '/filter_columns_for_relation',
      type: 'POST',
      data: {csrfmiddlewaretoken: window.CSRF_TOKEN, fk:this.value},
      success: function (data)
      {
          console.log(data);
          $("#master_table_relation_column_select").empty()
          for(i=0; i<data.Result.length; i++)
          {
            console.log(data.Result[i]);
            $("#master_table_relation_column_select").append('<option value="'+data.Result[i].pk+'">'+data.Result[i].c_name+'</option>')
          }
      },
      error:function(e){ console.log(e) }
    });
  });
  /* Relation column of tables fetching  end*/


  $(".baseform").click(function(event){

      /*************** CREATING MASTER TABLE  ***************/
      var bname = $("#bname").val();
      var tname = $("#tname").val();
      var table_type = $("#table_type").val();
      var table_discription = $("#table_discription").val();
      var table_purpose = $("#table_purpose").val();
      var table_bcp = $("#table_bcp").val();
      var tags = $("#tags").val();

      $.ajax({
        type:"POST",
        url: '/basemater',
        data:{csrfmiddlewaretoken: window.CSRF_TOKEN, bname:bname, tname:tname, table_type:table_type, table_discription:table_discription, table_purpose:table_purpose, table_bcp:table_bcp, tags:tags},
        async: false,
        success: function(data)
        {
            console.log(data);
        }
      });
      /*************** CREATING MASTER TABLE END ***************/

      /*************** CREATING COLUMNS ***************/
      var values = $("input[name='baycol_add']").map(function(){return $(this).val();}).get();
      var d_type = $(".coldatatype").map(function(){return $(this).val();}).get();
      fk= $("#bname").val();
      console.log("COLUMNS : "+values);
      console.log("VALUES : "+d_type);
      for(i =0; i<values.length; i++)
      {
        var colname = values[i];
        var type_d = d_type[i];
        console.log('Column Name : '+colname);
        console.log('Column Type : '+type_d);
        console.log("Fk : "+ fk);

        $.ajax({
          type:"POST",
          url: "/addcolumns",
          data:{csrfmiddlewaretoken: window.CSRF_TOKEN, colname:colname, fk:fk, type_d:type_d},
          async: false,
          success: function( data )
          {
            console.log(data);
          }
        });
      }
      /*************** CREATING COLUMNS END***************/

      key = $("#master_table_relation_column_select").val();
      m_key =  $("#master_table_relation_select").val();
      //var mx = $(".table_body").attr('id')
      name = $("#master_table_relation_column_select option:selected").text()
      console.log("key : "+ key);
      console.log("m_key : " + m_key);
      
      $.ajax({
        url: '/save_relation_column',
        type: 'POST',
        async: false,
        data: {csrfmiddlewaretoken: window.CSRF_TOKEN, key:key, m_key:m_key, name:name},
        success: function (data)
        {
            console.log(data);
        },
        error:function(e){ console.log(e) }
      });

      setTimeout(function()
      {
        location.reload();
      }, 2000);
    
  });
  
});


